// next.config.mjs
/** @type {import('next').NextConfig} */
const nextConfig = {
  // Konfiguraatioasetukset
};

export default nextConfig;
